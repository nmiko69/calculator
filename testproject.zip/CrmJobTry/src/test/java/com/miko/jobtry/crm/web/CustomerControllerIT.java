package com.miko.jobtry.crm.web;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ExchangeFilterFunctions;

import com.miko.jobtry.crm.CrmJobTryApplication;
import com.miko.jobtry.crm.web.dto.CustomerDto;

import reactor.core.publisher.Mono;

@SpringBootTest(classes = CrmJobTryApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase
public class CustomerControllerIT {

	private WebTestClient client;
	
	@Autowired
	CustomerController customerController;
	
	@LocalServerPort
	private int serverPort;
	
	@BeforeEach
	void setup() {
		client = WebTestClient
				.bindToServer().baseUrl(String.format("http://localhost:%d/CrmJobTry-1/api", serverPort))
				.filter(ExchangeFilterFunctions.basicAuthentication("bob", "pass"))
				.responseTimeout(Duration.ofMinutes(1)).build();
	}
	
	@Test
	void insertNewCustomer() {
		CustomerDto validCustomer = new CustomerDto(null, "Nagyházi Miklós", "", "");
		CustomerDto resultCustomer = client.post().uri("/customers")
				.headers(headers -> headers.setBasicAuth("bob", "pass"))
				.body(Mono.just(validCustomer), CustomerDto.class)
				.accept(MediaType.APPLICATION_JSON)
				.exchange().expectStatus().isOk().expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBody(CustomerDto.class).returnResult().getResponseBody();
		
		assertEquals(1l, resultCustomer.getId());
				
	}

	
	@Test
	void getFirstCustomer() {
		CustomerDto validCustomer = new CustomerDto(1l, "Nagyházi Miklós", "", "");
		CustomerDto resultCustomer = client.get().uri("/customers/1")
				.headers(headers -> headers.setBasicAuth("bob", "pass"))
				.accept(MediaType.APPLICATION_JSON)
				.exchange().expectStatus().isOk().expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBody(CustomerDto.class).returnResult().getResponseBody();
		
		assertEquals(validCustomer.getName(), resultCustomer.getName());
		assertEquals(validCustomer.getId(), resultCustomer.getId());
				
	}
	
}
