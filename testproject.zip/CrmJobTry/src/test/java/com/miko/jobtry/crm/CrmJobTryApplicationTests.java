package com.miko.jobtry.crm;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class CrmJobTryApplicationTests {
	
	@Autowired
	PropertySourceResolver propertySourceResolver;
	
	@Test
	public void shouldProfiledProperty_overridePropertyValues() {
		String firstProperty = propertySourceResolver.getFirstProperty();
		String secondProperty = propertySourceResolver.getSecondProperty();
		
		assertEquals("profile", firstProperty);
		assertEquals("defaultProfile", secondProperty);
	}

	@Test
	void contextLoads() {
	}

}
