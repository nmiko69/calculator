package com.miko.jobtry.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miko.jobtry.crm.dao.TypeOfSpace;

public interface TypeOfSpaceRepository extends JpaRepository<TypeOfSpace, Long> {

	TypeOfSpace findByName(String name);
	TypeOfSpace getTypeOfSpaceById(Long id);
	List<TypeOfSpace> findAll();
}
