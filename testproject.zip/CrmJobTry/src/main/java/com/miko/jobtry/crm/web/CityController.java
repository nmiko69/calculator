package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.City;
import com.miko.jobtry.crm.repository.CityRepository;

@RestController
@RequestMapping("/admin/cities")
public class CityController {
	
	@Autowired
	CityRepository cityRepository;
	
	@GetMapping
	public List<City> getAllCity() {
		return cityRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public City getCityById(@PathVariable Long id) {
		return cityRepository.getCityById(id);
	}
	
	@GetMapping("/exact/{city}")
	public City getCityByName(@PathVariable String city) {
		return cityRepository.findByName(city);
	}
	
	@GetMapping("/search/{city}")
	public List<City> findCityByName(@PathVariable String city) {
		return cityRepository.findByNameContainsIgnoreCase(city);
	}
	
	@PostMapping
	public City saveCity(@RequestBody City city) {
		return cityRepository.save(city);
	}

	@PostMapping("/delete")
	public City deleteCity(@RequestBody City city) {
		cityRepository.delete(city);
		city.setId(null);
		return city;
	}
}
