package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class TypeOfSpace {
	@Id
	@SequenceGenerator(name = "tos_seq", sequenceName="type_of_space_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "tos_seq")
	private Long id;	
	private String name;
	
	public TypeOfSpace() {
		super();
		id = null;
		name = "";
	}
	
	public TypeOfSpace(String name) {
		super();
		id = null;
		this.name = name;
	}

	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	

}
