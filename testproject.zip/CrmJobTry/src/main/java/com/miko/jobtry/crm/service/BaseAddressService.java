package com.miko.jobtry.crm.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.miko.jobtry.crm.dao.BaseAddress;
import com.miko.jobtry.crm.repository.BaseAddressRepository;


public class BaseAddressService {
	
	@Autowired
	TypeOfSpaceService typeOfSpaceService;
	@Autowired
	BaseAddressRepository baseAddressRepository;
	
	
	public BaseAddress save(BaseAddress baseAddress) {
		baseAddress.setTypeOfSpace(typeOfSpaceService.save(baseAddress.getTypeOfSpace()));
		return saveBaseAddress(baseAddress);
	}

	private BaseAddress saveBaseAddress(BaseAddress baseAddress) {
		if (baseAddress.getId()==null) {
			BaseAddress base = baseAddressRepository.findByNameAndType(baseAddress.getName(), baseAddress.getTypeOfSpace().getName());
			if (base==null)
				base = baseAddressRepository.save(baseAddress);
			
			baseAddress.setId(base.getId());
		} else {
			baseAddress = baseAddressRepository.save(baseAddress);
		}
		return baseAddress;
	}

	
	
	
	
	
}
