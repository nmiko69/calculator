package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class ZipCode {
	@Id
	@SequenceGenerator(name = "zipcode_seq", sequenceName="zip_code_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "zipcode_seq")
	private Long id;
	private String zipcode;
	@ManyToOne
	private City city;
	
	
	
	public ZipCode() {
		super();
		id = null;
		zipcode = "";
		city = null;
	}

	public ZipCode(String zipcode, City city) {
		super();
		id = null;
		this.zipcode = zipcode;
		this.city = city;
	}

	public String getZipcode() {
		return zipcode;
	}
	
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public City getCity() {
		return city;
	}
	
	public void setCity(City city) {
		this.city = city;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	

}
