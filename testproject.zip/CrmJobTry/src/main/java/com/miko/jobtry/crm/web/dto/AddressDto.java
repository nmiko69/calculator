package com.miko.jobtry.crm.web.dto;

public class AddressDto {
	Long id, customerId;
	String zipcode, city, place, placetype, location, remark;
	
	public AddressDto() {
		super();
		id = null;
		customerId = null;
		zipcode = "";
		city = "";
		place = "";
		placetype = "";
		location = "";
		remark = "";
	}
	
	public AddressDto(Long id, Long customerId, String zipcode, String city, String place, String placetype, String location, String remark) {
		super();
		this.id = id;
		this.zipcode = zipcode;
		this.city = city;
		this.place = place;
		this.placetype = placetype;
		this.location = location;
		this.remark = remark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getPlacetype() {
		return placetype;
	}

	public void setPlacetype(String placetype) {
		this.placetype = placetype;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public boolean isValid() {
		if (zipcode.trim().isEmpty() || city.trim().isEmpty() || place.trim().isEmpty() || placetype.trim().isEmpty())
			return false;
		else 
			return true;
		
	}
}
