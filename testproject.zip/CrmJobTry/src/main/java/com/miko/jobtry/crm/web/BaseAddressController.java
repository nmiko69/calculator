package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.BaseAddress;
import com.miko.jobtry.crm.repository.BaseAddressRepository;

@RestController
@RequestMapping("/admin/baseaddresses")
public class BaseAddressController {
	
	@Autowired
	BaseAddressRepository baseAddressRepository;
	
	@GetMapping
	public List<BaseAddress> getAllBaseAddress() {
		return baseAddressRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public BaseAddress getBaseAddressById(@PathVariable Long id) {
		return baseAddressRepository.findBaseAddressById(id);
	}
	
	@GetMapping("/exact/{street}/{streettype}")
	public BaseAddress getBaseAddressByName(
			@PathVariable String street,
			@PathVariable String streettype
			) {
		return baseAddressRepository.findByNameAndType(street, streettype);
	}
	
	@GetMapping("/search/{name}")
	public List<BaseAddress> findBaseAddressByName(@PathVariable String name) {
		return baseAddressRepository.findByNameContainsIgnoreCase(name);
	}
	
	@PostMapping
	public BaseAddress saveBaseAddress(@RequestBody BaseAddress baseAddress) {
		return baseAddressRepository.save(baseAddress);
	}

	@PostMapping("/delete")
	public BaseAddress deleteBaseAddress(@RequestBody BaseAddress baseAddress) {
		baseAddressRepository.delete(baseAddress);
		baseAddress.setId(null);
		return baseAddress;
	}
}
