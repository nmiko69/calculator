package com.miko.jobtry.crm;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.miko.jobtry.crm.export.ExportExcel;
import com.miko.jobtry.crm.export.ExportedCustomer;
import com.miko.jobtry.crm.service.AddressService;
import com.miko.jobtry.crm.service.BaseAddressService;
import com.miko.jobtry.crm.service.CustomerService;

@SpringBootApplication
public class CrmJobTryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrmJobTryApplication.class, args);
	}

	@Bean
	public AddressService addressService() {
		return new AddressService();
	}
	
	@Bean
	public BaseAddressService baseAddressService() {
		return new BaseAddressService();
	}
	
	@Bean
	public CustomerService customerService() {
		return new CustomerService();
	}
	
	@Bean
	public ExportExcel exportExcel() {
		return new ExportExcel();
	}
	
	
}
