package com.miko.jobtry.crm.export;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.miko.jobtry.crm.web.dto.AddressDto;

public class ExportExcel {
	
	private List<ExportedCustomer> customerList;
	private int sorszam;
	
	public ExportExcel(List<ExportedCustomer> customerList) {
		this.customerList = customerList;
		sorszam = 0;
	}
	
	public ExportExcel() {
		sorszam = 0;
	}
	
	public byte[] genExcel(List<ExportedCustomer> customerList) throws Exception {
		this.customerList = customerList;
		return genExcel();
	}
	
	public byte[] genExcel() throws Exception {
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("Customers");
		createHead(sheet);
		customerList.forEach( customer -> {
			createCustomerRow(customer, sheet);
		});
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		wb.write(baos);
	    return baos.toByteArray();
	}

	private void createCustomerRow(ExportedCustomer customer, HSSFSheet sheet) {
		HSSFRow row = createRow(sheet);
		row.createCell(0).setCellValue(new HSSFRichTextString(customer.getName()));
		customer.getAddressList().forEach(address -> {
			createAddressRow(address, sheet);
		});
	}
	
	private void createAddressRow(AddressDto address, HSSFSheet sheet) {
		HSSFRow row = createRow(sheet);
		row.createCell(0).setCellValue(address.getZipcode());
		row.createCell(1).setCellValue(address.getCity());
		row.createCell(2).setCellValue(address.getPlace());
		row.createCell(3).setCellValue(address.getPlacetype());
		row.createCell(4).setCellValue(address.getLocation());
		row.createCell(5).setCellValue(address.getRemark());
	}
	
	private void createHead(HSSFSheet sheet) {
		HSSFRow r1 = createRow(sheet);
		r1.createCell(1).setCellValue("Customer name");
		r1.createCell(2).setCellValue("Tax Num.");
		r1.createCell(3).setCellValue("Remark");
		sheet.setColumnWidth(0, 4000);
		sheet.setColumnWidth(1, 7000);
		sheet.setColumnWidth(2, 7000);
		sheet.setColumnWidth(3, 7000);
		sheet.setColumnWidth(4, 3000);
		sheet.setColumnWidth(3, 7000);
	}
	
    private HSSFRow createRow(HSSFSheet sheet) {
        HSSFRow r = sheet.createRow(sorszam);
        sorszam++;
        return r;
    }
	
}
