package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Address {
	@Id
	@SequenceGenerator(name = "address_seq", sequenceName="address_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "address_seq")
	private Long id;
	private Long customerId;
	@ManyToOne
	private ZipCode zipCode;
	@ManyToOne
	private BaseAddress baseAddress;
	private String location;
	private String remark;
	

	
	public Address() {
		super();
		location = "";
		remark = "";
	}



	public Address(Long id, Long customerId, String location, String remark, ZipCode zipCode, BaseAddress baseAddress) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.location = location;
		this.remark = remark;
		this.zipCode = zipCode;
		this.baseAddress = baseAddress;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getCustomerId() {
		return customerId;
	}



	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}



	public ZipCode getZipCode() {
		return zipCode;
	}



	public void setZipCode(ZipCode zipCode) {
		this.zipCode = zipCode;
	}



	public BaseAddress getBaseAddress() {
		return baseAddress;
	}



	public void setBaseAddress(BaseAddress baseAddress) {
		this.baseAddress = baseAddress;
	}



	public String getLocation() {
		return location;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public String getRemark() {
		return remark;
	}



	public void setRemark(String remark) {
		this.remark = remark;
	}

	
	

}
