package com.miko.jobtry.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miko.jobtry.crm.dao.City;
import com.miko.jobtry.crm.dao.ZipCode;

public interface ZipCodeRepository extends JpaRepository<ZipCode, Long> {
	
	ZipCode findByZipcode(String zipcode);
	ZipCode getZipCodeById(Long id);
	
	List<ZipCode> findByCity(City city);
	List<ZipCode> findAll();	
}
