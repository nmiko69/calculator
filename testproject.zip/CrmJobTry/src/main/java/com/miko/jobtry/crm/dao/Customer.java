package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;


@Entity
public class Customer {
	
	@Id
	@SequenceGenerator(name = "customer_seq", sequenceName="customer_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "customer_seq")
	private Long id;	
	private String name;
	private String taxNum;
	private String remark;

	public Customer() {
		name = "";
		taxNum = "";
		remark = "";
	}

	public Customer(Long id, String name, String taxNum, String remark) {
		super();
		this.id = id;
		this.name = name;
		this.taxNum = taxNum;
		this.remark = remark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTaxNum() {
		return taxNum;
	}

	public void setTaxNum(String taxNum) {
		this.taxNum = taxNum;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	

}
