package com.miko.jobtry.crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miko.jobtry.crm.dao.City;
import com.miko.jobtry.crm.repository.CityRepository;

@Component
public class CityService {

	@Autowired
	CityRepository cityRepository;
	
	public City saveCity(City city) {
		if (city.getId()==null) {
			City foundCity = cityRepository.findByName(city.getName());
			if (foundCity==null)
				foundCity = cityRepository.save(city);
			
			city.setId(foundCity.getId());
		} else {
			cityRepository.save(city);
		}
		return city;
	}
}
