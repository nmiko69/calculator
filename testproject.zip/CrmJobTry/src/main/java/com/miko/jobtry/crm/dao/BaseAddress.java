package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class BaseAddress {
	
	@Id
	@SequenceGenerator(name = "baseaddress_seq", sequenceName="base_address_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "baseaddress_seq")
	private Long id;	
	@ManyToOne
	private TypeOfSpace typeOfSpace;
	private String name;
	
	public BaseAddress() {
		super();
		id = null;
		typeOfSpace = null;
		name = "";
	}

	public BaseAddress(String name, TypeOfSpace typeOfSpace) {
		super();
		id = null;
		this.typeOfSpace = typeOfSpace;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TypeOfSpace getTypeOfSpace() {
		return typeOfSpace;
	}

	public void setTypeOfSpace(TypeOfSpace typeOfSpace) {
		this.typeOfSpace = typeOfSpace;
	}

}
