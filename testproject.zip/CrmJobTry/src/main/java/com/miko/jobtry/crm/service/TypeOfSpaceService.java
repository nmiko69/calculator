package com.miko.jobtry.crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miko.jobtry.crm.dao.TypeOfSpace;
import com.miko.jobtry.crm.repository.TypeOfSpaceRepository;

@Component
public class TypeOfSpaceService {

	@Autowired
	TypeOfSpaceRepository typeOfSpaceRepository;
	
	public TypeOfSpace save(TypeOfSpace typeOfSpace) {
		if (typeOfSpace.getId()==null) {
			TypeOfSpace type = typeOfSpaceRepository.findByName(typeOfSpace.getName());
			if (type==null) 
				type = typeOfSpaceRepository.save(typeOfSpace);
			
			typeOfSpace.setId(type.getId());
			
		} else {
			typeOfSpaceRepository.save(typeOfSpace);
		}
		return typeOfSpace;
	}
}
