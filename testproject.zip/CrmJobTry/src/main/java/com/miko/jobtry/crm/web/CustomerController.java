package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.Customer;
import com.miko.jobtry.crm.service.CustomerService;
import com.miko.jobtry.crm.web.dto.AddressDto;
import com.miko.jobtry.crm.web.dto.CustomerDto;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	
	
	@GetMapping
	public List<CustomerDto> getCustomers() {
		return customerService.findAll();
	}
	
	@GetMapping("/{id}")
	public CustomerDto getCustomerById(@PathVariable  Long id) {
		return customerService.getCustomerById(id);
	}
	
	@GetMapping("/search/{name}")
	public List<CustomerDto> searchCustomerByName(@PathVariable  String name) {
		
		return customerService.findByNameContainsIgnoreCase(name);
	}
	
	@GetMapping("/searchByAddress/{street}")
	public List<CustomerDto> searchCustomerByAddress(@PathVariable String street) {
		return customerService.searchByAddressContains(street);
	}
	
	@GetMapping("/searchByCity/{city}")
	public List<CustomerDto> searchCustomerByCity(@PathVariable  String cityname) {
		return customerService.searchByCityContains(cityname);
	}
	
	@PostMapping
	public CustomerDto save(@RequestBody CustomerDto customerDto) {
		return customerService.save(customerDto);
	}
	
	@PostMapping("/getAddresses")
	public List<AddressDto> getAddress(@RequestBody Customer customer) {
		return customerService.findAddressByCustomerId(customer.getId());
	}

	@PostMapping("/delete")
	public CustomerDto deleteCustomer(@RequestBody CustomerDto customerDto) {
		customerService.delete(customerDto);
		customerDto.setId(null);
		return customerDto;
	}
	
	@PostMapping("/getExcel")
	public byte[] getExcel(@RequestBody List<CustomerDto> customerDtoList) {
		try {
			return customerService.export(customerDtoList);
		} catch (Exception e) {
			return null;
		}
	}

	
}
