package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.TypeOfSpace;
import com.miko.jobtry.crm.dao.ZipCode;
import com.miko.jobtry.crm.repository.TypeOfSpaceRepository;

@RestController
@RequestMapping("/admin/typeofspaces")
public class TypeOfSpaceController {
	
	@Autowired
	TypeOfSpaceRepository typeOfSpaceRepository;
	
	@GetMapping
	public List<TypeOfSpace> getAllTypeOfSpace() {
		return typeOfSpaceRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public TypeOfSpace getTypeOfSpaceById(@PathVariable Long id) {
		return typeOfSpaceRepository.getTypeOfSpaceById(id);
	}
	
	@GetMapping("/get/{name}")
	public TypeOfSpace getTypeOfSpaceByName(@PathVariable String name) {
		return typeOfSpaceRepository.findByName(name);
	}
	
	
	@PostMapping
	public TypeOfSpace saveTypeOfSpace(@RequestBody TypeOfSpace typeOfSpace) {
		return typeOfSpaceRepository.save(typeOfSpace);
	}

	@PostMapping("/delete")
	public TypeOfSpace deleteTypeOfSpace(@RequestBody TypeOfSpace typeOfSpace) {
		typeOfSpaceRepository.delete(typeOfSpace);
		typeOfSpace.setId(null);
		return typeOfSpace;
	}
}
