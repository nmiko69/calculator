package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.Address;
import com.miko.jobtry.crm.repository.AddressRepository;
import com.miko.jobtry.crm.service.AddressService;
import com.miko.jobtry.crm.web.dto.AddressDto;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

	@Autowired
	AddressService addressService;
	@Autowired
	AddressRepository addressRepository;

	@GetMapping
	public List<AddressDto> findAll() {
		return addressService.findAll();
	}
	
	
	/*@GetMapping("/{$id}")
	public AddressDto getById(@PathVariable  Long id) {
		return addressService.getById(id);
	}*/
	
	@GetMapping("/{$id}")
	public Address getById(@PathVariable  Long id) {
		return addressRepository.getById(id);
	}
	
	@PostMapping
	public AddressDto save(@RequestBody AddressDto address) {
		return addressService.save(address);
	}	
	
	@PostMapping("/delete")
	public void deleteAddress(@RequestBody AddressDto address) {
		addressService.delete(address);
	}	
	
	
}
