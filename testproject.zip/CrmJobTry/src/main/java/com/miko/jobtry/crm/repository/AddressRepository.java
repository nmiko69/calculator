package com.miko.jobtry.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miko.jobtry.crm.dao.Address;
import com.miko.jobtry.crm.dao.BaseAddress;
import com.miko.jobtry.crm.dao.ZipCode;

public interface AddressRepository extends JpaRepository<Address, Long>  {

	List<Address> findByCustomerId(Long customerId);
	
	List<Address> findAll();
	
	Address getAddressById(Long id);
	
	Address getByCustomerIdAndBaseAddressAndLocationAndZipCode(Long customerId, BaseAddress baseAddress, String location, ZipCode zipCode);
	
}
