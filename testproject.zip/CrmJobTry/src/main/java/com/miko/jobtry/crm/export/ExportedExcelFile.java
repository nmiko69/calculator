package com.miko.jobtry.crm.export;

public class ExportedExcelFile {
	private byte[] bytearray;

	public byte[] getBytearray() {
		return bytearray;
	}

	public void setBytearray(byte[] bytearray) {
		this.bytearray = bytearray;
	}
	
	
}
