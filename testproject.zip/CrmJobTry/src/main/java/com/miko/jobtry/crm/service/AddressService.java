package com.miko.jobtry.crm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.miko.jobtry.crm.dao.Address;
import com.miko.jobtry.crm.dao.BaseAddress;
import com.miko.jobtry.crm.dao.City;
import com.miko.jobtry.crm.dao.Customer;
import com.miko.jobtry.crm.dao.TypeOfSpace;
import com.miko.jobtry.crm.dao.ZipCode;
import com.miko.jobtry.crm.repository.AddressRepository;
import com.miko.jobtry.crm.web.dto.AddressDto;
import com.miko.jobtry.crm.web.dto.CustomerDto;


public class AddressService {
	
	@Autowired
	BaseAddressService baseAddressService;
	@Autowired
	ZipCodeService zipCodeService;
	@Autowired
	AddressRepository addressRepository;
	
	
	public AddressDto getById(Long id) {
		return mappingDaoToDto(addressRepository.getById(id));
	}
	
	public List<AddressDto> findAll() {
		return mappingDaoListToDtoList(addressRepository.findAll());
	}

	
	public List<AddressDto> findByCustomerId(Long customerId) {
		return mappingDaoListToDtoList(addressRepository.findByCustomerId(customerId));
	}
	
	private Address checkAddress(Long customerId, BaseAddress baseAddress, String location, ZipCode zipCode) {
		return addressRepository.getByCustomerIdAndBaseAddressAndLocationAndZipCode(customerId, baseAddress, location, zipCode);
	}
	
	public AddressDto save(AddressDto addressDto) {
		if (addressDto.getCustomerId()==null)
			return null;
		
		Address address = mappingDtoToDao(addressDto);
		address.setZipCode(zipCodeService.save(address.getZipCode()));
		address.setBaseAddress(baseAddressService.save(address.getBaseAddress()));
		
		return mappingDaoToDto(saveAddress(address));
			
	}
	
	
	private Address saveAddress(Address address) {
		if (address.getId()==null) {
			Address tryAddress = checkAddress(address.getCustomerId(), address.getBaseAddress(), address.getLocation(), address.getZipCode());
			if (tryAddress!=null) 
				address.setId(tryAddress.getId());
		}
		
		return addressRepository.save(address);
	}

	public void delete(AddressDto addressDto) {
		addressRepository.delete(mappingDtoToDao(addressDto));
	}

	private List<AddressDto> mappingDaoListToDtoList(List<Address> addressList) {
		if (addressList==null) 
			return null;
		else if (addressList.isEmpty())
			return new ArrayList<>();
		else {
			List<AddressDto> ret = new ArrayList<>();
			addressList.forEach( address -> {
				ret.add(mappingDaoToDto(address));
			});
			return ret;
		}
					
	}
	
	private AddressDto mappingDaoToDto(Address address) {
		if (address==null) 
			return null;
		else
			return new AddressDto(address.getId(), 
					address.getCustomerId(),
					address.getZipCode().getZipcode(), 
					address.getZipCode().getCity().getName(),
					address.getBaseAddress().getName(),
					address.getBaseAddress().getTypeOfSpace().getName(),
					address.getLocation(),
					address.getRemark()
					);
	}
	
	private List<Address> mappingDtoListToDaoList(List<AddressDto> addressDtoList) {
		if (addressDtoList==null) 
			return null;
		else if (addressDtoList.isEmpty())
			return new ArrayList<>();
		else {
			List<Address> ret = new ArrayList<>();
			addressDtoList.forEach( addressDto -> {
				ret.add(mappingDtoToDao(addressDto));
			});
			return ret;
		}
					
	}
	
	private Address mappingDtoToDao(AddressDto addressDto) {
		if (addressDto==null)
			return null;
		else 
			return new Address(
					addressDto.getId(), 
					addressDto.getCustomerId(), 
					addressDto.getLocation(), 
					addressDto.getRemark(),
					new ZipCode(addressDto.getZipcode(), new City(addressDto.getCity())),
					new BaseAddress(addressDto.getPlace(), new TypeOfSpace(addressDto.getPlacetype()))
					);
	}	
}
