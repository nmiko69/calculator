package com.miko.jobtry.crm.web.dto;

public class CustomerDto {
	Long id;
	String name, taxnum, remark;
	
	public CustomerDto() {
		super();
		id = null;
		name = "";
		taxnum = "";
		remark = "";
	}
	
	public CustomerDto(Long id, String name, String taxnum, String remark) {
		super();
		this.id = id;
		this.name = name;
		this.taxnum = taxnum;
		this.remark = remark;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTaxnum() {
		return taxnum;
	}

	public void setTaxnum(String taxnum) {
		this.taxnum = taxnum;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	public boolean isValid() {
		if (name.trim().isEmpty()) 
			return false;
		else
			return true;
	}
	
}
