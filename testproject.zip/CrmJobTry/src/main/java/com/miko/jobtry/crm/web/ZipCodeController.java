package com.miko.jobtry.crm.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.miko.jobtry.crm.dao.ZipCode;
import com.miko.jobtry.crm.repository.ZipCodeRepository;

@RestController
@RequestMapping("/admin/zipcodes")
public class ZipCodeController {

	@Autowired
	ZipCodeRepository zipCodeRepository;
	
	@GetMapping
	public List<ZipCode> getAllZipCode() {
		return zipCodeRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public ZipCode getZipCodeById(@PathVariable Long id) {
		return zipCodeRepository.getZipCodeById(id);
	}
	
	@GetMapping("/exact/{zipcode}")
	public ZipCode getZipCodeByZipcode(@PathVariable String zipcode) {
		return zipCodeRepository.findByZipcode(zipcode);
	}
	
	@PostMapping
	public ZipCode saveZipCode(@RequestBody ZipCode zipCode) {
		return zipCodeRepository.save(zipCode);
	}

	@PostMapping("/delete")
	public ZipCode deleteZipCode(@RequestBody ZipCode zipCode) {
		zipCodeRepository.delete(zipCode);
		zipCode.setId(null);
		return zipCode;
	}
}
