package com.miko.jobtry.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miko.jobtry.crm.dao.BaseAddress;

public interface BaseAddressRepository extends JpaRepository<BaseAddress, Long> {

	@Query(value = "SELECT b.* FROM base_address b INNER JOIN type_of_space t on (t.id=type_of_space_id) WHERE b.name=:name AND t.name=:typename", nativeQuery=true)
	BaseAddress findByNameAndType(String name, String typename);
	
	BaseAddress findBaseAddressById(Long id);
	List<BaseAddress> findByNameContainsIgnoreCase(String name);
}
