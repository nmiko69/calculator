package com.miko.jobtry.crm.export;

import java.util.ArrayList;
import java.util.List;

import com.miko.jobtry.crm.dao.Address;
import com.miko.jobtry.crm.web.dto.AddressDto;

public class ExportedCustomer  {
	private String name;
	
	private final List<AddressDto> addressList = new ArrayList<>();
	
	public ExportedCustomer(String name) {
		this.name = name;
	}
	
	public ExportedCustomer() {
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void addAddress(AddressDto address) {
		addressList.add(address);
	}

	public List<AddressDto> getAddressList() {
		return addressList;
	}
	
}
