package com.miko.jobtry.crm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.miko.jobtry.crm.dao.Customer;
import com.miko.jobtry.crm.export.ExportExcel;
import com.miko.jobtry.crm.export.ExportedCustomer;
import com.miko.jobtry.crm.repository.CustomerRepository;
import com.miko.jobtry.crm.web.dto.AddressDto;
import com.miko.jobtry.crm.web.dto.CustomerDto;

public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AddressService addressService;
	@Autowired
	ExportExcel exportExcel;
	
	
	
	public List<CustomerDto> findAll() {
		return mappingDaoListToDtoList(customerRepository.findAll());
	}
	
	public List<AddressDto> findAddressByCustomerId(Long customerId) {
		return addressService.findByCustomerId(customerId);
	}
	
	public CustomerDto findByName(String name) {		
		return mappingDaoToDto(customerRepository.findByName(name));
	}
	
	public CustomerDto getCustomerById(Long id) {
		return mappingDaoToDto(customerRepository.getCustomerById(id));
	}
	
	public List<CustomerDto> findByNameContainsIgnoreCase(String name) {
		return mappingDaoListToDtoList(customerRepository.findByNameContainsIgnoreCase(name));
	}
	
	public List<CustomerDto> searchByLocationContains(String location) {
		return mappingDaoListToDtoList(customerRepository.searchByLocationContains(location));
	}
	
	public List<CustomerDto> searchByAddressContains(String address) {
		return mappingDaoListToDtoList(customerRepository.searchByAddressContains(address));
	}
	
	public List<CustomerDto> searchByZipcodeContains(String zipcode) {
		return mappingDaoListToDtoList(customerRepository.searchByZipcodeContains(zipcode));
	}
	
	public List<CustomerDto> searchByCityContains(String cityname) {
		return mappingDaoListToDtoList(customerRepository.searchByCityContains(cityname));
	}
	
	public void delete(CustomerDto customerDto) {
		customerRepository.delete(mappingDtoToDao(customerDto));
	}
	
	public CustomerDto save(CustomerDto customerDto) {
		Customer customer = customerRepository.save(mappingDtoToDao(customerDto));
		return mappingDaoToDto(customer);
	}
	
	public byte[] export(List<CustomerDto> customerDtoList) throws Exception {
		return exportExcel.genExcel(generateExportedCustomerList(mappingDtoListToDaoList(customerDtoList)));
	}
	
	private List<ExportedCustomer> generateExportedCustomerList(List<Customer> customerList) {
		List<ExportedCustomer> excelList = new ArrayList<>();
		customerList.stream().forEach(customer -> {
			ExportedCustomer exportedCustomer = new ExportedCustomer(customer.getName());
			addressService.findByCustomerId(customer.getId()).forEach(address -> {
				exportedCustomer.addAddress(address);
			});
			excelList.add(exportedCustomer);
		});
		return excelList;
	}	
	

	private List<CustomerDto> mappingDaoListToDtoList(List<Customer> customerList) {
		if (customerList==null) 
			return null;
		else if (customerList.isEmpty())
			return new ArrayList<>();
		else {
			List<CustomerDto> ret = new ArrayList<>();
			customerList.forEach( customer -> {
				ret.add(mappingDaoToDto(customer));
			});
			return ret;
		}
					
	}
	
	private CustomerDto mappingDaoToDto(Customer customer) {
		if (customer==null) 
			return null;
		else
			return new CustomerDto(customer.getId(), customer.getName(), customer.getTaxNum(), customer.getRemark());
	}
	
	private List<Customer> mappingDtoListToDaoList(List<CustomerDto> customerDtoList) {
		if (customerDtoList==null) 
			return null;
		else if (customerDtoList.isEmpty())
			return new ArrayList<>();
		else {
			List<Customer> ret = new ArrayList<>();
			customerDtoList.forEach( customerDto -> {
				ret.add(mappingDtoToDao(customerDto));
			});
			return ret;
		}
					
	}
	
	
	private Customer mappingDtoToDao(CustomerDto customerDto) {
		if (customerDto==null)
			return null;
		else 
			return new Customer(customerDto.getId(), customerDto.getName(), customerDto.getTaxnum(), customerDto.getRemark());
	}
}
