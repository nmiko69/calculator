package com.miko.jobtry.crm.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class City {
	@Id
	@SequenceGenerator(name = "city_seq", sequenceName="city_id_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator= "city_seq")
	private Long id;
	private String name;
	
	public City() {
		super();
		id = null;
		name = "";
	}

	public City(String name) {
		super();
		id = null;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
