package com.miko.jobtry.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.miko.jobtry.crm.dao.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	public static final String SELECT_ADDRESS_BY_ZIPCODE = " INNER JOIN zip_code ON (zip_code_id=zip_code.id)";
	public static final String SELECT_CUSTOMER_BY_ADDRESS = "SELECT DISTINCT c.* FROM customer c INNER JOIN address ON (customer_id=c.id)";

	List<Customer> findAll();
	Customer findByName(String name);
	Customer getCustomerById(Long id);
	
	List<Customer> findByNameContainsIgnoreCase(String name);
	
	@Query(value = SELECT_CUSTOMER_BY_ADDRESS + " WHERE address.location ilike %:location% ORDER BY c.name", nativeQuery = true)
	List<Customer> searchByLocationContains(@Param("location") String location);

	@Query(value = SELECT_CUSTOMER_BY_ADDRESS + " INNER JOIN base_address ON (base_address_id=base_address.id) WHERE base_address.name ilike %:address% ORDER BY c.name", nativeQuery = true)
	List<Customer> searchByAddressContains(@Param("address") String address);

	@Query(value = SELECT_CUSTOMER_BY_ADDRESS + SELECT_ADDRESS_BY_ZIPCODE + " WHERE zip_code.zipcode ilike :zipcode% ORDER BY c.name", nativeQuery = true)
	List<Customer> searchByZipcodeContains(@Param("zipcode") String zipcode);
	
	@Query(value = SELECT_CUSTOMER_BY_ADDRESS + SELECT_ADDRESS_BY_ZIPCODE + " INNER JOIN city on (city_id=city.id) WHERE city.name ilike %:cityname% ORDER BY c.name", nativeQuery = true)
	List<Customer> searchByCityContains(@Param("cityname") String cityname);
	
	
}
