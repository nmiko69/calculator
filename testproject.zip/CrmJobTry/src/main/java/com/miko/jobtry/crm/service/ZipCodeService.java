package com.miko.jobtry.crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miko.jobtry.crm.dao.ZipCode;
import com.miko.jobtry.crm.repository.ZipCodeRepository;

@Component
public class ZipCodeService {

	@Autowired
	ZipCodeRepository zipCodeRepository;
	@Autowired
	CityService cityService;
	
	public ZipCode save(ZipCode zipCode) {
		zipCode.setCity(cityService.saveCity(zipCode.getCity()));
		if (zipCode.getId()==null) {
			ZipCode zip = zipCodeRepository.findByZipcode(zipCode.getZipcode());
			if (zip==null) 
				zip = zipCodeRepository.save(zipCode);
		
			zipCode.setId(zip.getId());
		} else {
			zipCode = zipCodeRepository.save(zipCode);
		}
		return zipCode;
	}


	
}
