--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: jobtrycrm; Type: DATABASE; Schema: -; Owner: miko
--

CREATE DATABASE jobtrycrm WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'hu_HU.UTF-8' LC_CTYPE = 'hu_HU.UTF-8';


ALTER DATABASE jobtrycrm OWNER TO postgres;

\connect jobtrycrm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    base_address_id bigint NOT NULL,
    location character varying(255) DEFAULT ''::character varying,
    remark text DEFAULT ''::text,
    zip_code_id bigint NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_id_seq OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;


--
-- Name: base_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_address (
    id bigint NOT NULL,
    type_of_space_id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.base_address OWNER TO postgres;

--
-- Name: base_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.base_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.base_address_id_seq OWNER TO postgres;

--
-- Name: base_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.base_address_id_seq OWNED BY public.base_address.id;


--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.city_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.city_id_seq OWNER TO postgres;

--
-- Name: city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.city_id_seq OWNED BY public.city.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying,
    tax_num character varying(32) DEFAULT ''::character varying,
    remark text DEFAULT ''::text
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: type_of_space; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_of_space (
    id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.type_of_space OWNER TO postgres;

--
-- Name: type_of_space_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.type_of_space_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_of_space_id_seq OWNER TO postgres;

--
-- Name: type_of_space_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.type_of_space_id_seq OWNED BY public.type_of_space.id;


--
-- Name: zip_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zip_code (
    id bigint NOT NULL,
    zipcode character varying(32) DEFAULT ''::character varying,
    city_id bigint NOT NULL
);


ALTER TABLE public.zip_code OWNER TO postgres;

--
-- Name: zip_code_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zip_code_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zip_code_id_seq OWNER TO postgres;

--
-- Name: zip_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zip_code_id_seq OWNED BY public.zip_code.id;


--
-- Name: address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN id SET DEFAULT nextval('public.address_id_seq'::regclass);


--
-- Name: base_address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_address ALTER COLUMN id SET DEFAULT nextval('public.base_address_id_seq'::regclass);


--
-- Name: city id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city ALTER COLUMN id SET DEFAULT nextval('public.city_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: type_of_space id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_of_space ALTER COLUMN id SET DEFAULT nextval('public.type_of_space_id_seq'::regclass);


--
-- Name: zip_code id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zip_code ALTER COLUMN id SET DEFAULT nextval('public.zip_code_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, customer_id, base_address_id, location, remark, zip_code_id) FROM stdin;
2	1	2	14	munkahely	1
4	1	4	65		1
3	2	3	61		3
1	1	1	3/B	otthoni	1
8	1	5	41		4
\.


--
-- Data for Name: base_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_address (id, type_of_space_id, name) FROM stdin;
1	1	Köztelek
2	2	Bécsi
3	2	Kerepesi
4	2	Tihanyi Árpád
5	7	Vértesszöllős
\.


--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (id, name) FROM stdin;
1	Győr
2	Budapest
3	Tatabánya
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, name, tax_num, remark) FROM stdin;
2	VAN GRAAF		
1	Nagyházi Miklós		
4	Banczalo	2	törölni
\.


--
-- Data for Name: type_of_space; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type_of_space (id, name) FROM stdin;
1	utca
2	út
3	tér
4	tere
5	útja
7	utcája
\.


--
-- Data for Name: zip_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zip_code (id, zipcode, city_id) FROM stdin;
1	9025	1
2	9024	1
3	1106	2
4	2837	3
\.


--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_id_seq', 8, true);


--
-- Name: base_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.base_address_id_seq', 5, true);


--
-- Name: city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.city_id_seq', 3, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 4, true);


--
-- Name: type_of_space_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.type_of_space_id_seq', 7, true);


--
-- Name: zip_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zip_code_id_seq', 4, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: base_address base_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_address
    ADD CONSTRAINT base_address_pkey PRIMARY KEY (id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: type_of_space type_of_space_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_of_space
    ADD CONSTRAINT type_of_space_pkey PRIMARY KEY (id);


--
-- Name: zip_code zip_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zip_code
    ADD CONSTRAINT zip_code_pkey PRIMARY KEY (id);


--
-- Name: fki_address_base_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_address_base_address ON public.address USING btree (base_address_id);


--
-- Name: fki_address_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_address_customer ON public.address USING btree (customer_id);


--
-- Name: fki_address_zip_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_address_zip_code ON public.address USING btree (zip_code_id);


--
-- Name: fki_base_address_type_of_space; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_base_address_type_of_space ON public.base_address USING btree (type_of_space_id);


--
-- Name: fki_zip_code_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_zip_code_city ON public.zip_code USING btree (city_id);


--
-- Name: address address_base_address; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_base_address FOREIGN KEY (base_address_id) REFERENCES public.base_address(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: address address_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_customer FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: address address_zip_code; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_zip_code FOREIGN KEY (zip_code_id) REFERENCES public.zip_code(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: base_address base_address_type_of_space; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_address
    ADD CONSTRAINT base_address_type_of_space FOREIGN KEY (type_of_space_id) REFERENCES public.type_of_space(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zip_code zip_code_city; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zip_code
    ADD CONSTRAINT zip_code_city FOREIGN KEY (city_id) REFERENCES public.city(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

